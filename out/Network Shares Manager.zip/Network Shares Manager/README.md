# decky-NetworkSharesManager

Manage your network shares from inside Gaming Mode